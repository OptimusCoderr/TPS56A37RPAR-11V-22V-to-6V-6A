*PADS-LIBRARY-PART-TYPES-V9*

IHLP3232DZER4R7M01 INDPM8682X400N I IND 7 1 0 0 0
TIMESTAMP 2026.01.16.17.51.03
"Mouser Part Number" 70-IHLP3232DZER4R7M0
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/IHLP3232DZER4R7M01?qs=IyEhILxByaNeTMh9BOKUIg%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" IHLP3232DZER4R7M01
"Description" Vishay, IHLP-3232DZ-01, 3232 Shielded Wire-wound SMD Inductor with a Metal Composite Core, 4.7 uH +/-20% Wire-Wound 7.25A
"Datasheet Link" https://www.vishay.com/docs/34316/ihlp-3232dz-01.pdf
"Geometry.Height" 4mm
GATE 1 2 0
IHLP3232DZER4R7M01
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
399955/1815362/2.50/2/2/Inductor
