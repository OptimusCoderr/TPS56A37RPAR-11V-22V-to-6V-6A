*PADS-LIBRARY-PART-TYPES-V9*

74479276168 INDC2016X100N I IND 7 1 0 0 0
TIMESTAMP 2026.01.16.21.10.31
"Mouser Part Number" 710-74479276168
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/74479276168?qs=16w8nSHsg3sOz9tIBO1mJw%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 74479276168
"Description" WE-PMCI Power Molded Chip Inductor Size 201610; L = 0.68 H; IR = 3.8 A; Isat = 4 A; RDC = 45 m
"Datasheet Link" https://www.we-online.com/components/products/download/WE-PMCI_201610_3D+%28rev1%29.pdf
"Geometry.Height" 1mm
GATE 1 2 0
74479276168
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
531996/1815362/2.50/2/2/Inductor
