*PADS-LIBRARY-PART-TYPES-V9*

TB0011-350-02GR TB001135002GR I CON 7 1 0 0 0
TIMESTAMP 2026.01.17.15.21.41
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" TB0011-350-02GR
"Description" 2 Poles, Screw Type, Horizontal, 3.50 Pitch, 24~18 (AWG), Green, Terminal Block Connector
"Datasheet Link" https://www.sameskydevices.com/product/resource/tb0011-350.pdf
"Geometry.Height" 8.9mm
GATE 1 2 0
TB0011-350-02GR
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
21454716/1815362/2.50/2/3/Connector
